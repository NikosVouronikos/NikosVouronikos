/*
 * Nikolaos Vouronikos 
 * CSE University of Ioannina
 * A.I. Project 2020-2021
 * This is a game where user plays against computer
 * Each player tries to be the last who has a valid move on a MxN table
 * Developed with eclipse-workspace
 * Class worktest has all the functions which are used in order to design the game
 */

import java.util.*;
public class worktest {
	
	private int M;								/*Number of rows */
	private int N;								/*Number of columns */
	private Integer table[][];					/*Main game table */
	private int playerA[];						/*Position of playerA */
	private int playerB[];						/*Position of playerB */
	
	
	/*
	 * Constructor name : worktest
	 * Arguments : integer x and integer y
	 * Goal : Initialize main game table and the positions of the two players in it
	 */
	public worktest(int x,int y) {
		M = x;
		N = y;
		table = new Integer[M][N];
		playerA = new int[2];
		playerB = new int[2];
	}
	
	/* 
	 * Method name : initializeTable
	 * No argument
	 * Return value : MxN matrix consisted of integers
	 * 0 means empty position
	 * 1 means blackened position(Invalid)
	 */
	public Integer[][] initializeTable() {
		Random rand = new Random();
		/* First initialize the matrix with zeros */
		for(int i = 0; i < this.M; i++) {
			for(int j = 0; j < this.N; j++) {
				table[i][j] = 0;
			}
		}
		int k;	/* Number of blackened positions */
		if((M < 4) && (N < 4)) {
			k = 2;
		}
		else if((M >= 4) && (M < 10) && (N >= 4) && (N < 10)){
			k = (M*N) - ((M*N)/2);
		}
		else {
			k = (M*N)/2;
		}
		/*Blacken some positions randomly in order to decrease the possible moves*/
		for(int i = 0; i < k; i++) {
			int x = rand.nextInt(M);
			int y = rand.nextInt(N);
			if(table[x][y] == 1) {		/*Already blackened */
				i--;
				continue;
			}
			else {
				table[x][y] = 1;
			}
		}
		return this.gettable();
	}
	
	/* 
	 * Method name : searchA
	 * Arguments : MxN matrix a
	 * Return value : matrix consisted of two integers(x and y coordinates of playerA)
	 */
	public Integer[] searchA(Integer[][] a) { 
		Integer[] pos = new Integer[2];
		for(int i = 0; i < M; i++) {
			for(int j = 0; j < N; j++) {
				if(a[i][j] == 65) {				/* 65 is the number which we use to identify the position of player A */
					pos[0] = i;
					pos[1] = j;
				}
			}
		}
		return pos;
	}
	
	/*
	 * Same as player A but here -65 is the number of player B identification 
	 */
	public Integer[] searchB(Integer[][] a) { 
		Integer[] pos = new Integer[2];
		for(int i = 0; i < M; i++) {
			for(int j = 0; j < N; j++) {
				if(a[i][j] == -65) {
					pos[0] = i;
					pos[1] = j;
				}
			}
		}
		return pos;
	}
	
	/* Return the position of the state given inside game tree */
	public int search_State(ArrayList<Integer[][]> a, Integer[][] b) { 
		for(int i = 0; i < a.size(); i++) {
			if(this.check_if_equal(b, a.get(i))) {
				return i;
			}
		}
		return -1;
	}
	
	/*Given the choice of playerB check if he gave a valid position or not and return true or false */
	public boolean is_valid(ArrayList<Integer[]> vp, int x , int y) { 
		Integer[] p = {x,y};
		for(Integer[] a : vp) {
			if(this.check_if_equal(p, a)) {
				return true;
			}
		}
		return false;
	}
	
	/*
	 * Print method for user interface
	 */
	public void print_table(Integer a[][]) {
		
		for(int i = 0; i < this.getM(); i++) {
			for(int j = 0; j < this.getN(); j++) {
				if(a[i][j] == 65) {
					System.out.print("A" + " | ");
				}
				else if(a[i][j] == -65) {
					System.out.print("B" + " | ");
				}
				else if(a[i][j] == 1) {
					System.out.print("X" + " | ");
				}
				else {
					System.out.print("_" + " | ");
				}
			}
			System.out.println();
		}
	}
	
	/*
	 * Function : get_validpositions
	 * Arguments : x,y ---> current position of A
	 * a ---> current state
	 * Return value : ArrayList with all the posible moves of A ---> Matrix with length == 2 (x,y)
	 */
	public ArrayList<Integer[]> get_validpositions(int x,int y,Integer[][] a){
		
		ArrayList<Integer[]> positions = new ArrayList<Integer[]>();						/*here we hold the new positions that come from the current position of the player(IF THEY ARE VALID)*/
		int count = 8;
		int movex = 1;
		int movey = 1;
		while(count != 6) 																	/*First check movement only in x. Occasions(x + 1 or x - 1)*/ {
			int newx = x + movex;
			if((newx < 0) || (newx > (this.getM()-1))){										/*Check if new position is out of bounds */
				count--;
				movex = -1;
				continue;
			}
			int value = a[newx][y];
																							/*if we are in bounds then check if we are about to go to a black position or if is the other player there */
			if(value == 1) {
				count--;
				movex = -1;
				continue;
			}
			else if((value == 65) || (value == -65)){
				count--;
				movex = -1;
				continue;
			}
			else {
				Integer[] pos = {newx,y};
				positions.add(pos);
				count--;
				movex = -1;
				continue;
			}
		}
		
		while(count != 4) {																	/*Then check movement only in y. Occasions(y + 1 or y - 1)*/
			int newy = y + movey;
			if((newy < 0) || (newy > (this.getN()-1))){ 									/*Check if new position is out of bounds */
				count--;
				movey = -1;
				continue;
			}
			int value = a[x][newy];
																							/*if we are in bounds then check if we are about to go to a black position or if is the other player there */
			if(value == 1) {
				count--;
				movey = -1;
				continue;
			}
			else if((value == 65) || (value == -65)){
				count--;
				movey = -1;
				continue;
			}
			else {
				Integer[] pos = {x,newy};
				positions.add(pos);
				count--;
				movey = -1;
				continue;
			}
		}
		int internalcount = 0;
		while(count != 0) {																	/*Finally check movement in both x and y(Diagonal). Occasions : (x + 1 y + 1)/(x + 1 y - 1)/(x - 1 y + 1)/(x - 1 y - 1)*/
			if(internalcount == 0) {
				movex = 1;
				movey = 1;
			}
			else if(internalcount == 1) {
				movex = 1;
				movey = -1;
			}
			else if(internalcount == 2) {
				movex = -1;
				movey = 1;
			}
			else {
				movex = -1;
				movey = -1;
			}
			int newx = x + movex;
			int newy = y + movey;
			if((newx < 0) || (newx > (this.getM()-1)) || (newy < 0) || (newy > (this.getN()-1))){	/*Check if new position is out of bounds */
				count--;
				internalcount++;
				continue;
			}
			int value = a[newx][newy];
																									/*if we are in bounds then check if we are about to go to a black position or if is the other player there */
			if(value == 1) {
				count--;
				internalcount++;
				continue;
			}
			else if((value == 65) || (value == -65)){
				count--;
				internalcount++;
				continue;
			}
			else {
				Integer[] pos = {newx,newy};
				positions.add(pos);
				count--;
				internalcount++;
				continue;
			}
		}
		return positions 																			/*Finally take all the possible moves from player's current position */;
	}
	
	/*
	 * Deep copy of matrix a
	 * Return value : deep copy b
	 */
	public Integer[][] copytable(Integer[][] a){
		Integer[][] b = new Integer[this.getM()][this.getN()];
		for(int i = 0; i < this.getM(); i++) {
			for(int j = 0; j < this.getN(); j++) {
				b[i][j] = a[i][j];
			}
		}
		return b;
	}
	
	/*
	 * Set playerA(MAX) to table randomly(Initialization) 
	 */
	public void setA_to_table(){ 
		
		Random rand = new Random();
		boolean c = true;
		while(c) {
			int x = rand.nextInt(M);
			int y = rand.nextInt(N);
			if((((this.gettable())[x][y]) == 1) || (((this.gettable())[x][y]) == -65)) { 			/* check if the position is empty (Blackened(1) and the other player there(A = 65) */
				continue;
			}
			else {
				this.setplayerA(x, y);
				(this.gettable())[x][y] = 65;
				c = false;
			}
			
		}
		this.settable(this.gettable());
	}
	
	/*
	 * Set playerB(MIN) to table randomly(Initialization) 
	 */
	public void setB_to_table(){ 
		
		Random rand = new Random();
		boolean c = true;
		while(c) {
			int x = rand.nextInt(M);
			int y = rand.nextInt(N);
			if((((this.gettable())[x][y]) == 1) || (((this.gettable())[x][y]) == 65)) { 			/* check if the position is empty (Blackened(1) and the other player there(A = 65) */
				continue;
			}
			else {
				this.setplayerB(x, y);
				(this.gettable())[x][y] = -65;
				c = false;
			}
			
		}
		this.settable(this.gettable());
	}
	
	public boolean check_if_equal(Integer[][] a , Integer[][] b) { /* 2D Version */
		
		for(int i = 0; i < M; i++) {
			for(int j = 0; j < N; j++) {
				if(a[i][j] != b[i][j]) {
					return false;
				}
			}
		}
		return true;
	}
	
	public boolean check_if_equal(Integer[] a , Integer[] b) { /* 1D Version */
		int length = a.length;
		for(int i = 0; i < length; i++) {
			if(a[i] != b[i]) {
				return false;
			}
		}
		return true;
	}
	
	/* 
	 * MINIMAX Algorithm using ArrayLists
	 */
	public ArrayList<Integer> minimax(ArrayList<Integer[][]> tree,ArrayList<Integer> values,ArrayList<Integer> num_of_parents,ArrayList<Integer[][]> parents,int depth,boolean isMax){		
		if(depth == 0) { 																				/*Reached root so return the final values */
			return values;
		}
		if(isMax) {																						/*PlayerA is playing */	
			int max = -10;
			int par_in_level = num_of_parents.get(depth-1);
			if(par_in_level == 0) {
				return minimax(tree,values,num_of_parents,parents,depth-1,false) ;
			}
			ArrayList<Integer> maxvalues = new ArrayList<Integer>();
			int offset = 0;
			for(int i = 0; i < depth - 1; i++) {
				offset = offset + num_of_parents.get(i);
			}
			int limit = offset + par_in_level;
			for(int i = offset; i < limit; i++) {
				max = -10;
				Integer[][] a = new Integer[M][N];
				a = this.copytable(parents.get(i));
				Integer[] posA = this.searchA(a);											/*Check where is player A */
 				ArrayList<Integer[]> pos = this.get_validpositions(posA[0], posA[1], a);	/*Take all the possible moves of playerA */
				if(pos.size() == 0) {														/*Player A has no possible moves so playerB wins.Add the table to HashMap with value = -1 */  
					continue;
				}
				for(int j = 0; j < pos.size(); j++) { 										/*If not then run a loop over the possible moves of A*/
					Integer[][] b = new Integer[M][N];
					b = this.copytable(a);
					int newxa = (pos.get(j))[0];											/*Take new x and new y*/
					int newya = (pos.get(j))[1];
					for(int k = 0; k < M; k++) {											/*Put A in the new positions and add the new tables in max ArrayList in order to do the same thing when MIN will play */
						for(int l = 0; l < N; l++) {
							if(b[k][l] == 65) {
								b[k][l] = 1;
								b[newxa][newya] = 65;
							}
							else {
								continue;
							}
						}
					}
					int position = 0;
					for(int k = 0; k < tree.size(); k++) {
						if(this.check_if_equal(b, tree.get(k))) {
							position = k;
							break;
						}
					}
					int value = values.get(position);
					maxvalues.add(value);
				}
				for(int l = 0; l < maxvalues.size(); l++) {
					int check = maxvalues.get(l);
					if(check > max) {
						max = check;
					}
				}
				int posparent = 0;
				for(int k = 0; k < tree.size(); k++) {
					if(this.check_if_equal(a, tree.get(k))) {
						posparent = k;
					}
				}
				values.set(posparent, max);
				maxvalues.clear();
			}
			return minimax(tree,values,num_of_parents,parents,depth-1,false);
		}
		else {
			int min = 10;
			int par_in_level = num_of_parents.get(depth-1);
			if(par_in_level == 0) {
				return minimax(tree,values,num_of_parents,parents,depth-1,true) ;
			}
			ArrayList<Integer> minvalues = new ArrayList<Integer>();
			int offset = 0;
			for(int i = 0; i < depth - 1; i++) {
				offset = offset + num_of_parents.get(i);
			}
			int limit = offset + par_in_level;
			for(int i = offset; i < limit; i++) {
				min = 10;
				Integer[][] a = new Integer[M][N];
				a = this.copytable(parents.get(i));
				Integer[] posB = this.searchB(a);											/*Check where is player B */
				ArrayList<Integer[]> pos = this.get_validpositions(posB[0], posB[1], a);	/*Take all the possible moves of playerb */
				if(pos.size() == 0) {														/*Player B has no possible moves so playerA wins.Add the table to HashMap with value = 1 */  
					continue;
				}
				for(int j = 0; j < pos.size(); j++) { 										/*If not then run a loop over the possible moves of B*/
					Integer[][] b = new Integer[M][N];
					b = this.copytable(a);
					int newxb = (pos.get(j))[0];											/*Take new x and new y*/
					int newyb = (pos.get(j))[1];
					for(int k = 0; k < M; k++) {											/*Put B in the new positions and add the new tables in max ArrayList in order to do the same thing when MAX will play */
						for(int l = 0; l < N; l++) {
							if(b[k][l] == -65) {
								b[k][l] = 1;
								b[newxb][newyb] = -65;
							}
							else {
								continue;
							}
						}
					}
					int position = 0;
					for(int k = 0; k < tree.size(); k++) {
						if(this.check_if_equal(b, tree.get(k))) {
							position = k;
							break;
						}
					}
					int value = values.get(position);
					minvalues.add(value);
				}
				for(int l = 0; l < minvalues.size(); l++) {
					int check = minvalues.get(l);
					if(check < min) {
						min = check;
					}
				}
				int posparent = 0;
				for(int k = 0; k < tree.size(); k++) {
					if(this.check_if_equal(a, tree.get(k))) {
						posparent = k;
					}
				}
				values.set(posparent, min);
				minvalues.clear();
			}
			return minimax(tree,values,num_of_parents,parents,depth-1,true);
		}
	}
	
	/*Setters and getters for class fields */
	
	public int getM() {
		return M;
	}
	
	public void setM(int x) {
		M = x;
	}
	
	public int getN() {
		return N;
	}
	
	public void setN(int y) {
		N = y;
	}
	
	public int[] getplayerA() {
		return playerA;
	}
	
	public void setplayerA(int x,int y) {
		playerA[0] = x;
		playerA[1] = y;
	}
	
	public int[] getplayerB() {
		return playerB;
	}
	
	public void setplayerB(int x,int y) {
		playerB[0] = x;
		playerB[1] = y;
	}
	
	public Integer[][] gettable(){
		return table;
	}
	
	public void settable(Integer[][] t) { /* Deep copy */
		for(int i = 0; i < t.length; i++) {
			for(int j = 0; j < t[i].length; j++) {
				table[i][j] = t[i][j];
			}
		}
	}
}