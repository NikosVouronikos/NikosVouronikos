/*
 * Nikolaos Vouronikos 
 * CSE University of Ioannina
 * A.I. Project 2020-2021
 * This is a game where user plays against computer
 * Each player tries to be the last who has a valid move on a MxN table
 * Developed with eclipse-workspace
 * Class testing includes main function and the U.I.
 */

import java.util.*;
import java.lang.Math;
public class testing {

	public static void main(String[] args) {
		
		/*RULE 1 : Only one position at a time
		 *RULE 2 : 65 means PlayerA and -65 means Player B(Coding)
		 *Run program ---> java program_name M N
		 */
		
		int M = Integer.parseInt(args[0]); /* First _argument is M */
		int N = Integer.parseInt(args[1]); /* Second _argument is N */
		/* Check for wrong input */
		if((M < 0) || (N < 0)){
			System.out.println("Wrong input.Exiting...");
			System.exit(0);
		}
		
		String turn = "MAX"; /* Define which player is to about to play */
		Scanner input = new Scanner(System.in);
		
		/* Initializations */
		worktest obj = new worktest(M,N);
		int depth = 0;																		/*count depth ---> level 1(root),level 2,level 3....etc.*/
		int par = 0; 																		/*count how many parents are inside the game tree(states with states children */
		Integer[][] table;																	/*Main game table */
		ArrayList<Integer[][]> max = new ArrayList<Integer[][]>();							/*moves of max */
		ArrayList<Integer[][]> min = new ArrayList<Integer[][]>();							/*moves of min */
		ArrayList<Integer[][]> parents = new ArrayList<Integer[][]>();						/*all states with children */
		ArrayList<Integer[][]> copytree = new ArrayList<Integer[][]>(); 					/*copy of the keys of game tree in an arraylist */
		ArrayList<Integer> num_of_parents = new ArrayList<Integer>();						/*how many parents has each level */
		ArrayList<Integer> values = new ArrayList<Integer>();								/*copy of the values of game tree in an arraylist */
		LinkedHashMap<Integer[][],Integer> tree = new LinkedHashMap<Integer[][],Integer>(); /*game tree -> Key = State , Value = +1,-1 or 0(uninitialized) */
		table = obj.initializeTable();
		obj.setA_to_table(); 																/*set player A to table randomly */
		obj.setB_to_table(); 																/*set player B to table randomly */
		obj.settable(table);
		/* Initializations */
		
		System.out.println("Game Table :");
		System.out.println("-------------------");
		obj.print_table(table);
		System.out.println("-------------------");
		tree.put(obj.gettable(),0);
		min.add(obj.gettable());
		int pow = (int)(Math.pow(M, N));
	
		/* Main proccess to completely produce the game tree
		 * Maximum number of loops is M^N   
		 * Starting with MAX and in every step we change between MAX and MIN  
		 * Adding in game tree(LinkedHashMap) every possible state(Integer[][] table) along with its value 
		 */
		for(int p = 0; p < pow; p++) {
			if(turn.equals("MAX")) { /* PlayerA's turn */
				depth++;
				par = 0;
				for(int i = 0; i < min.size(); i++) {
					Integer[][] a = min.get(i);															/*Get all the posible states of MIN */
					Integer[] posA = obj.searchA(a);													/*Check where is player A */
					ArrayList<Integer[]> pos = obj.get_validpositions(posA[0], posA[1], a);				/*Take all the possible moves of playerA */
					if(pos.size() == 0) {																/*Player A has no possible moves so playerB wins.Add the table to HashMap with value = -1 */  
						tree.put(a, -1);
						continue;
					}
					parents.add(a); 									/*if A has possible moves it means that this state will have children in the tree */
					par++;												/*increase parents by 1 */
					for(int j = 0; j < pos.size(); j++) { 				/*If not then run a loop over the possible moves of A*/
						Integer[][] b = new Integer[M][N];				/*b will be every possible state from current position of A */
						b = obj.copytable(a);
						int newxa = (pos.get(j))[0];					/*Take new x and new y*/
						int newya = (pos.get(j))[1];
						for(int k = 0; k < M; k++) {					/*Put A in the new positions and add the new tables in max ArrayList in order to do the same thing when MIN will play */
							for(int l = 0; l < N; l++) {
								if(b[k][l] == 65) {
									b[k][l] = 1;
									b[newxa][newya] = 65;				/*Set A to the new position and return the new table */
								}
								else {
									continue;
								}
							}
						}
						max.add(b);
						tree.put(b, 0);	/*non terminating so add it with zero value ---> when we will call minimax this value will change */
					}
				}
				num_of_parents.add(par);
				min.clear();	/*Clear for MAX when he will play again */
				turn = "MIN";	/*Stop with MAX, next will be MIN */
			}
			/*Same process with MAX */
			else if(turn.equals("MIN")) {
				depth++;
				par = 0;
				for(int i = 0; i < max.size(); i++) {
					Integer[][] a = max.get(i);
					Integer[] posB = obj.searchB(a);
					ArrayList<Integer[]> pos = obj.get_validpositions(posB[0], posB[1], a);
					if(pos.size() == 0) {
						tree.put(a, 1);
						continue;
					}
					parents.add(a);
					par++;
					for(int j = 0; j < pos.size(); j++) {
						Integer[][] b = new Integer[M][N];
						b = obj.copytable(a);
						int newxb = (pos.get(j))[0];
						int newyb = (pos.get(j))[1];
						for(int k = 0; k < M; k++) {
							for(int l = 0; l < N; l++) {
								if(b[k][l] == -65) {
									b[k][l] = 1;
									b[newxb][newyb] = -65;
								}
								else {
									continue;
								}
							}
						}
						min.add(b);
						tree.put(b, 0);
					}
				}
				num_of_parents.add(par);
				max.clear();
				turn = "MAX";
			}
			if((max.size() == 0) && (min.size() == 0)){ /*When both are empty means that we are finished so stop */
				break;
			}
		}
		
		/*Copy to ArrayLists in order to call minimax
		 * Keys ---> copytree
		 * Values ---> values
		 */
		for(Integer[][] a : tree.keySet()) {
			copytree.add(a);
			values.add(tree.get(a));
		}
		
		/*Call minimax to propagate the values to root ---> Recursion */
		if((depth % 2) == 0) {
			values = obj.minimax(copytree,values, num_of_parents, parents, depth, false);
		}
		else {
			values = obj.minimax(copytree,values, num_of_parents, parents, depth, true);
		}
		/*Main proccess ends here ---> All states have values either -1 or 1 */
		
		/*Game is starting now */
		
		boolean con = true;
		turn = "MAX";
		Integer[][] currentstate = new Integer[M][N];
		Integer[][] nextstate = new Integer[M][N];
		nextstate = obj.copytable(obj.gettable());
		
		/*Main process for UI */
		while(con) {
			if(turn.equals("MAX")) {
				System.out.println("PlayerA is ready to play...");
				ArrayList<Integer[][]> children = new ArrayList<Integer[][]>();
				ArrayList<Integer> chpositions = new ArrayList<Integer>();
				int posofmax = 0;
				int maxi = -10;
				currentstate = obj.copytable(nextstate);
				Integer[] posA = obj.searchA(currentstate);
				ArrayList<Integer[]> nextmoves = obj.get_validpositions(posA[0], posA[1], currentstate);
				if(nextmoves.size() == 0) {
					con = false;
					System.out.println("Player A has no possible moves");
					System.out.println("You win!!!");
					continue;
				}
				else {
					for(int j = 0; j < nextmoves.size(); j++) {
						Integer[][] b = new Integer[M][N];
						b = obj.copytable(currentstate);
						int newxb = (nextmoves.get(j))[0];
						int newyb = (nextmoves.get(j))[1];
						for(int k = 0; k < M; k++) {
							for(int l = 0; l < N; l++) {
								if(b[k][l] == 65) {
									b[k][l] = 1;
									b[newxb][newyb] = 65;
								}
								else {
									continue;
								}
							}
						}
						children.add(b);
					}
					for(int k = 0; k < children.size(); k++) {
						int pos = obj.search_State(copytree, children.get(k));
						chpositions.add(pos);
					}
					for(int l = 0; l < chpositions.size(); l++) {
						int value = values.get(chpositions.get(l));
						if(value == 0) {
							continue;
						}
						if(value > maxi) {
							maxi = value;
							posofmax = chpositions.get(l);
						}
					}
					nextstate = obj.copytable(copytree.get(posofmax));
					System.out.println("Player A finished playing : ");
					System.out.println("-----------");
					obj.print_table(nextstate);
					System.out.println("-----------");
					turn = "MIN";
				}
			}
			else {
				currentstate = obj.copytable(nextstate);
				Integer[] posB = obj.searchB(currentstate);
				ArrayList<Integer[]> nextmoves = obj.get_validpositions(posB[0], posB[1], currentstate);
				if(nextmoves.size() == 0) {
					con = false;
					System.out.println("Player B has no possible moves");
					System.out.println("Computer wins!!!");
					continue;
				}
				else {
					System.out.println("Player B is your turn.");
					System.out.println("Give x (0,1,...M-1) : ");
					int x = input.nextInt();
					System.out.println("Give y (0,1,...N-1) : ");
					int y = input.nextInt();
					if(!(obj.is_valid(nextmoves, x, y))) {
						System.out.println("Invalid position.Try again.");
						nextstate = obj.copytable(currentstate);
						continue;
					}
					else {
						Integer[][] b = new Integer[M][N];
						b = obj.copytable(currentstate);
						for(int i = 0; i < M; i++) {
							for(int j = 0; j < N; j++) {
								if(b[i][j] == -65) {
									b[i][j] = 1;
									b[x][y] = -65;
								}
								else {
									continue;
								}
							}
						}
						nextstate = obj.copytable(b);
						System.out.println("Player B finished playing : ");
						System.out.println("------------------");
						obj.print_table(nextstate);
						System.out.println("------------------");
						turn = "MAX";
					}
				}
			}
		}
		input.close();
	}
}